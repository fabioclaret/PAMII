package com.example.intellimoney.AppUtil;

public class AppUtil {
    public static final int TIME_SPLASH = 3500;
    public static final int TIME_SPLASH2 = 1500;
    public static final int TIME_SPLASH3 = 1100;
}
