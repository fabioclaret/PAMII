package com.example.intellimoney.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.intellimoney.R;
import com.example.intellimoney.model.Carteira;

import java.util.List;

public class CarteiraAdapter extends RecyclerView.Adapter<CarteiraAdapter.ViewHolderCarteira>{

    private List<Carteira> listarCarteiras;

    public CarteiraAdapter(List<Carteira> listarCarteiras){
        this.listarCarteiras = listarCarteiras;
    }


    @NonNull
    @Override
    public ViewHolderCarteira onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View listaContas = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_contas, parent, false);

        return new ViewHolderCarteira(listaContas);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderCarteira holder, int position) {

       Carteira carteira = listarCarteiras.get(position);

        holder.txtNomeConta.setText(carteira.getNome_carteira());
        holder.txtValorConta.setText(String.valueOf( carteira.getSaldo()));
    }

    @Override
    public int getItemCount() {
        return this.listarCarteiras.size();
    }

    public class ViewHolderCarteira extends RecyclerView.ViewHolder{

        public TextView txtNomeConta, txtValorConta;

        public ViewHolderCarteira(@NonNull View itemView) {
            super(itemView);

            txtNomeConta  = itemView.findViewById(R.id.txtNomeConta);
            txtValorConta = itemView.findViewById(R.id.txtSaldoConta);
        }
    }
}
