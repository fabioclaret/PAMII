package com.example.intellimoney.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.intellimoney.R;
import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.model.Transacoes;

import java.util.List;

public class TransacaoAdapter extends RecyclerView.Adapter<TransacaoAdapter.ViewHolderTransacao> {

    private List<Transacoes> listarTransacoes;

    public TransacaoAdapter(List<Transacoes> listarTransacoes){
        this.listarTransacoes = listarTransacoes;
    }

    @NonNull
    @Override
    public ViewHolderTransacao onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View listaTransacoes = LayoutInflater.from(parent.getContext()).inflate(R.layout.lista_transacoes, parent, false);

        return new ViewHolderTransacao(listaTransacoes);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolderTransacao holder, int position) {
        Transacoes transacoes = this.listarTransacoes.get(position);

        holder.txtNomeTransacao.setText(transacoes.getDecricao());
        holder.txtValorTransacao.setText(String.valueOf(transacoes.getValor_transacao()));
        holder.txtDataTransacao.setText(transacoes.getData_transasao());
        holder.txtCategoriaTransacao.setText(transacoes.getNomeCategoria());
    }

    @Override
    public int getItemCount() {
        return this.listarTransacoes.size();
    }

    public class ViewHolderTransacao extends RecyclerView.ViewHolder{

        public TextView txtNomeTransacao, txtDataTransacao, txtValorTransacao, txtCategoriaTransacao;

        public ViewHolderTransacao(@NonNull View itemView) {
            super(itemView);

            txtNomeTransacao      = itemView.findViewById(R.id.txtNomeTransacao);
            txtValorTransacao     = itemView.findViewById(R.id.txtValorTransacao);
            txtDataTransacao      = itemView.findViewById(R.id.txtDataTransacao);
            txtCategoriaTransacao = itemView.findViewById(R.id.txtCategoriaTransacao);
        }
    }

}
