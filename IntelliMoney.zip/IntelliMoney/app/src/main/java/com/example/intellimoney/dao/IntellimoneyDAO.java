package com.example.intellimoney.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.model.Categorias;
import com.example.intellimoney.model.Objetivo;
import com.example.intellimoney.model.Transacoes;
import com.example.intellimoney.model.Usuario;
import com.example.intellimoney.telasApp.MinhasContasApp;

import java.util.ArrayList;
import java.util.List;

public class IntellimoneyDAO extends SQLiteOpenHelper {
    public static final String NAME = "intellimoney.sqLite";
    public static final int VERSION = 13;

    SQLiteDatabase database;
    Usuario usuario;

    public IntellimoneyDAO(@Nullable Context context) {
        super(context, NAME, null, VERSION);
        Log.i("TAG", "IntellimoneyDatabase: Banco de Dados criado!");
    }

    @Override
    public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
        if(!db.isReadOnly()){
            db.execSQL("PRAGMA foreign_keys=ON;");
        }
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Instancia do metodo com a criação da tabela usuario
        db.execSQL(ScriptDB.criarTabelaUsuario());
        db.execSQL(ScriptDB.criarTabelaCategorias());
        db.execSQL(ScriptDB.criarTabelaObjetivo());
        db.execSQL(ScriptDB.criarTabelaCarteira());
        db.execSQL(ScriptDB.criarTabelaPlanejamento());
        db.execSQL(ScriptDB.criarTabelaTransacoes());
        db.execSQL(ScriptDB.criarTabelaPlanejamentoCategoria());

        Log.i("TAG", "IntellimoneyDatabase: tabelas criadas!");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(ScriptDB.excluirTabelaObjetivo());
        onCreate(db);
    }

    public boolean cadastrarUsuario(Usuario usuario){

        try {
            SQLiteDatabase database = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put("nome", usuario.getNome());
            values.put("email", usuario.getEmail());
            values.put("senha", usuario.getSenha());

            database.insert("usuario", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    public boolean redefinirSenha(Usuario usuario){
       try {
           SQLiteDatabase database = getWritableDatabase();
           ContentValues values = new ContentValues();

           values.put("senha", usuario.getSenha());

           database.update("usuario", values, "email = ?", new String[]{String.valueOf(usuario.getEmail())});
           return true;

       }catch (SQLiteException e){
           return false;
       }
    }

    public boolean autenticaUsuario(String email, String senha){
        String sql = "SELECT * FROM usuario WHERE email = ? AND senha = ?";

        database = this.getWritableDatabase();

        Cursor cursor = database.rawQuery(sql, new String[]{email, senha});

        if(cursor.getCount() > 0){
            return true;
        }else{
            return false;
        }
    }

    @SuppressLint("Range")
    public List<Usuario> buscarUsuario(String email, String senha){

        database = getReadableDatabase();

        String sql = "SELECT * FROM usuario WHERE email = "+ "'"+email+"'" + " AND senha = "+ "'"+senha+"'";

        Cursor cursor = database.rawQuery(sql, null);

        int result = cursor.getCount();
        Log.i("TAG", "buscarUsuario: "+ result);

        int teste=0;

        List<Usuario> listaUsuario = new ArrayList<Usuario>();

        //cursor.moveToFirst();
        while(cursor.moveToNext()) {
            usuario = new Usuario();

            String nomeUsuario  = cursor.getString(cursor.getColumnIndex("nome"));
            String emailUsuario = cursor.getString(cursor.getColumnIndex("email"));
            int idUsuario       = cursor.getInt(cursor.getColumnIndex("id_usuario"));


            usuario.setNome(nomeUsuario);
            usuario.setEmail(emailUsuario);
            usuario.setId_usuario(idUsuario);

            listaUsuario.add(usuario);
        }


        return listaUsuario;
    }

    public boolean insereCategorias(Categorias categorias){

        try {
            SQLiteDatabase database = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put("nome_categoria", categorias.getNome_categoria());
            values.put("tipo_categoria", categorias.getTipo_categoria());

            database.insert("categorias", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    public boolean insereDespesa(Transacoes transacoes){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        try {

            values.put("descricao", transacoes.getDecricao());
            values.put("valor_transacao", transacoes.getValor_transacao());
            values.put("data_transacao", transacoes.getData_transasao());
            values.put("categoria", transacoes.getCategoria());
            values.put("carteira", transacoes.getCarteira());
            values.put("usuario", transacoes.getFk_usuario());
            values.put("tipo_transacao", transacoes.getTipo());

            database.insert("transacoes", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    public boolean insereReceita(Transacoes transacoes){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        try {

            values.put("descricao", transacoes.getDecricao());
            values.put("valor_transacao", transacoes.getValor_transacao());
            values.put("data_transacao", transacoes.getData_transasao());
            values.put("categoria", transacoes.getCategoria());
            values.put("carteira", transacoes.getCarteira());
            values.put("usuario", transacoes.getFk_usuario());
            values.put("tipo_transacao", transacoes.getTipo());

            database.insert("transacoes", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    public boolean insereObjetivo(Objetivo objetivo){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        try {

            values.put("valor_objetivo", objetivo.getValor_objetivo());
            values.put("valor_deposito", objetivo.getValor_deposito());
            values.put("nome_objetivo", objetivo.getNome_objetivo());
            values.put("data_objetivo", objetivo.getData_objetivo());
            values.put("descricao", objetivo.getDescricao());
            values.put("usuario", objetivo.getUsuario());

            database.insert("objetivo", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    public boolean criaCarteira(Carteira carteira){

        try {
            SQLiteDatabase database = this.getWritableDatabase();
            ContentValues values = new ContentValues();

            values.put("nome_carteira", carteira.getNome_carteira());
            values.put("saldo", carteira.getSaldo());
            values.put("usuario", carteira.getFk_usuario());

            database.insert("carteira", null, values);

            return true;

        }catch (SQLiteException e){
            return false;
        }
    }

    @SuppressLint("Range")
    public List<Transacoes> listarTransacoes(){
        String sql = "SELECT T.descricao, T.data_transacao, T.valor_transacao, T.categoria, C.nome_categoria FROM transacoes T, categorias C" +
                "     WHERE (C.id_categoria = T.categoria) ORDER BY T.data_transacao DESC;";

        database = getWritableDatabase();
        Cursor cursor = database.rawQuery(sql, null);

        List<Transacoes> listaTransacoes = new ArrayList<Transacoes>();

        while (cursor.moveToNext()){
            Transacoes transacao = new Transacoes();

            String descricaoTransacao = cursor.getString(cursor.getColumnIndex("T.descricao"));
            String dataTransacao      = cursor.getString(cursor.getColumnIndex("T.data_transacao"));
            float valorTransacao      = cursor.getFloat(cursor.getColumnIndex("T.valor_transacao"));
            int categoria             = cursor.getInt(cursor.getColumnIndex("T.categoria"));
            String nomeCategoria      = cursor.getString(cursor.getColumnIndex("C.nome_categoria"));

            transacao.setDecricao(descricaoTransacao);
            transacao.setValor_transacao(valorTransacao);
            transacao.setData_transasao(dataTransacao);
            transacao.setCategoria(categoria);
            transacao.setNomeCategoria(nomeCategoria);

            listaTransacoes.add(transacao);
        }

        return listaTransacoes;
    }

    @SuppressLint("Range")
    public List<Carteira> listarContas(){
        String sql = "SELECT * FROM carteira ";//, usuario U WHERE U.id_usuario = C.usuario";

        database = getReadableDatabase();
        Cursor cursor = database.rawQuery(sql, null);


        List<Carteira> listaCarteiras = new ArrayList<Carteira>();

        while (cursor.moveToNext()){
            Carteira carteira = new Carteira();

            String nomeCarteira = cursor.getString(cursor.getColumnIndex("C.nome_carteira"));
            float saldoCarteira = cursor.getFloat(cursor.getColumnIndex("C.saldo"));

            carteira.setNome_carteira(nomeCarteira);
            carteira.setSaldo(saldoCarteira);

            listaCarteiras.add(carteira);
        };
        return listaCarteiras;
    }

    @SuppressLint("Range")
    public void mostrarValorConta(){
        String sql = "SELECT C.saldo FROM carteira C, usuario U WHERE C.usuario = U.id_usuario ";
         database = getReadableDatabase();
         Cursor cursor = database.rawQuery(sql, null);

         Carteira carteira = new Carteira();

         carteira.setSaldo(cursor.getFloat(cursor.getColumnIndex("C.saldo")));
    }

}
