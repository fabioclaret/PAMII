package com.example.intellimoney.dao;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.Contract;

public class ScriptDB {

    public static String criarTabelaUsuario(){
        String sql = "CREATE TABLE IF NOT EXISTS usuario ( \n" +
                "     id_usuario INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,  \n" +
                "     nome VARCHAR(50) NOT NULL DEFAULT (''),  \n" +
                "     email VARCHAR(50) UNIQUE NOT NULL DEFAULT (''),  \n" +
                "     senha VARCHAR(8) NOT NULL DEFAULT (''))";

        return sql;
    }

    public static String criarTabelaCategorias(){
        String sql = "CREATE TABLE IF NOT EXISTS categorias ( \n" +
                "     id_categoria INTEGER PRIMARY KEY,  \n" +
                "     nome_categoria VARCHAR(50)," +
                "     tipo_categoria TEXT)";

        return sql;
    }

    public static String criarTabelaCarteira(){
        String sql = "CREATE TABLE IF NOT EXISTS carteira ( \n" +
                "     id_carteira INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,  \n" +
                "     nome_carteira TEXT NOT NULL, \n" +
                "     saldo FLOAT(10,2) DEFAULT 0,  \n" +
                "     usuario INTEGER NOT NULL," +
                "     FOREIGN KEY(usuario) REFERENCES usuario (id_usuario))";

        return sql;
    }

    public static String criarTabelaObjetivo(){
        String sql = "CREATE TABLE IF NOT EXISTS objetivo ( \n" +
                "     id_objetivo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,  \n" +
                "     valor_objetivo FLOAT(10,2) DEFAULT 0,  \n" +
                "     valor_deposito FLOAT(10,2) DEFAULT 0,  \n" +
                "     nome_objetivo VARCHAR(50) NULL,  \n" +
                "     data_objetivo DATE NULL,  \n" +
                "     descricao VARCHAR(100),  \n" +
                "     usuario INTEGER NOT NULL," +
                "     FOREIGN KEY(usuario) REFERENCES usuario (id_usuario))";

        return sql;
    }

    public static String criarTabelaPlanejamento(){
        String sql = "CREATE TABLE IF NOT EXISTS planejamento ( \n" +
                "     id_planejamento INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,  \n" +
                "     valor_inicial FLOAT(10,2) DEFAULT 0,  \n" +
                "     porcentagem_gasto INTEGER DEFAULT 80,  \n" +
                "     valor_total FLOAT(10,2) DEFAULT 0,  \n" +
                "     usuario INTEGER NOT NULL," +
                "     FOREIGN KEY(usuario) REFERENCES usuario (id_usuario))";

        return sql;
    }

    public static String criarTabelaTransacoes(){
        String sql = "CREATE TABLE IF NOT EXISTS transacoes ( \n" +
                "     id_transacao INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, \n" +
                "     valor_transacao FLOAT(10,2) DEFAULT 0, \n" +
                "     data_transacao DATE NULL,  \n" +
                "     descricao VARCHAR(100) NULL,  \n" +
                "     usuario INTEGER NOT NULL,  \n" +
                "     planejamento INTEGER NULL,  \n" +
                "     categoria INTEGER NOT NULL, \n" +
                "     carteira INTEGER NOT NULL," +
                "     tipo_transacao TEXT NOT NULL, " +
                "     FOREIGN KEY(usuario) REFERENCES usuario (id_usuario),\n" +
                "     FOREIGN KEY(planejamento) REFERENCES planejamento (id_planejamento),\n" +
                "     FOREIGN KEY(categoria) REFERENCES categorias (id_categoria),\n" +
                "     FOREIGN KEY(carteira) REFERENCES carteira (id_carteira))";

        return sql;
    }

    public static String criarTabelaPlanejamentoCategoria(){
        String sql = "CREATE TABLE IF NOT EXISTS planejamento_categoria ( \n" +
                "     id_planejamento_categoria INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,\n" +
                "     valor_categoria FLOAT(10,2) DEFAULT 0,  \n" +
                "     planejamento INTEGER NOT NULL,  \n" +
                "     categoria_saida INTEGER NOT NULL," +
                "     FOREIGN KEY(planejamento) REFERENCES planejamento (id_planejamento),\n" +
                "     FOREIGN KEY(categoria_saida) REFERENCES categorias (id_categoria))";

        return sql;
    }

    public static String adicionarChaveEstrangeira(){
        String sql = "ALTER TABLE entrada ADD FOREIGN KEY(categoria) REFERENCES categoria_entrada (id_categoria_entrada);\n" +
                "ALTER TABLE entrada ADD FOREIGN KEY(usuario) REFERENCES usuario (id_usuario);\n" +
                "ALTER TABLE entrada ADD FOREIGN KEY(carteira) REFERENCES carteira (id_carteira);\n" +
                "ALTER TABLE objetivo ADD FOREIGN KEY(usuario) REFERENCES usuario (id_usuario);\n" +
                "ALTER TABLE planejamento ADD FOREIGN KEY(usuario) REFERENCES usuario (id_usuario);\n" +
                "ALTER TABLE saida ADD FOREIGN KEY(usuario) REFERENCES usuario (id_usuario);\n" +
                "ALTER TABLE saida ADD FOREIGN KEY(planejamento) REFERENCES planejamento (id_planejamento);\n" +
                "ALTER TABLE saida ADD FOREIGN KEY(categoria_saida) REFERENCES categoria_saida (id_categoria_saida);\n" +
                "ALTER TABLE saida ADD FOREIGN KEY(carteira) REFERENCES carteira (id_carteira);\n" +
                "ALTER TABLE carteira ADD FOREIGN KEY(usuario) REFERENCES usuario (id_usuario);\n" +
                "ALTER TABLE planejamento_categoria ADD FOREIGN KEY(planejamento) REFERENCES planejamento (id_planejamento);\n" +
                "ALTER TABLE planejamento_categoria ADD FOREIGN KEY(categoria_saida) REFERENCES categoria_saida (id_categoria_saida);";

        return sql;
    }

    public static String excluirTabelaUsuario() {
        String sql ="DROP TABLE usuario";

        return sql;
    }

    public static String excluirTabelaTransacoes() {
        String sql ="DROP TABLE transacoes";

        return sql;
    }

    public static String excluirTabelaCarteira() {
        String sql ="DROP TABLE carteira";

        return sql;
    }

    public static String excluirTabelaCategorias() {
        String sql ="DROP TABLE categorias";

        return sql;
    }

    public static String excluirTabelaPlanejamentoCategoria() {
        String sql ="DROP TABLE planejamento_categoria";

        return sql;
    }

    public static String excluirTabelaObjetivo() {
        String sql ="DROP TABLE objetivo";

        return sql;
    }
}
