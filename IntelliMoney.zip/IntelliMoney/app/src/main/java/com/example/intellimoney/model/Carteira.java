package com.example.intellimoney.model;

import java.io.Serializable;

public class Carteira implements Serializable {
    private int id_carteira, fk_usuario;
    private String nome_carteira;
    private float saldo;

    public int getId_carteira() {
        return id_carteira;
    }

    public void setId_carteira(int id_carteira) {
        this.id_carteira = id_carteira;
    }

    public int getFk_usuario() {
        return fk_usuario;
    }

    public void setFk_usuario(int fk_usuario) {
        this.fk_usuario = fk_usuario;
    }

    public String getNome_carteira() {
        return nome_carteira;
    }

    public void setNome_carteira(String nome_carteira) {
        this.nome_carteira = nome_carteira;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
}
