package com.example.intellimoney.model;

import java.util.Date;

public class Objetivo {
    private int id_objetivo, usuario;
    private String nome_objetivo, descricao;
    private float valor_deposito, valor_objetivo;
    private String data_objetivo;

    public int getId_objetivo() {
        return id_objetivo;
    }

    public void setId_objetivo(int id_objetivo) {
        this.id_objetivo = id_objetivo;
    }

    public int getUsuario() {
        return usuario;
    }

    public void setUsuario(int usuario) {
        this.usuario = usuario;
    }

    public String getNome_objetivo() {
        return nome_objetivo;
    }

    public void setNome_objetivo(String nome_objetivo) {
        this.nome_objetivo = nome_objetivo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValor_deposito() {
        return valor_deposito;
    }

    public void setValor_deposito(float valor_deposito) {
        this.valor_deposito = valor_deposito;
    }

    public float getValor_objetivo() {
        return valor_objetivo;
    }

    public void setValor_objetivo(float valor_objetivo) {
        this.valor_objetivo = valor_objetivo;
    }

    public String getData_objetivo() {
        return data_objetivo;
    }

    public void setData_objetivo(String data_objetivo) {
        this.data_objetivo = data_objetivo;
    }
}
