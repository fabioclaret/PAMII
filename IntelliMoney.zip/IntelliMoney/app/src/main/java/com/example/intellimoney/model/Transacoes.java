package com.example.intellimoney.model;

import java.io.Serializable;

public class Transacoes implements Serializable {
    private int id_transacao, categoria, planejamento, carteira, fk_usuario;
    private float valor_transacao;
    private String data_transasao, decricao, tipo, nomeCategoria;


    public int getId_transacao() {
        return id_transacao;
    }

    public void setId_transacao(int id_transacao) {
        this.id_transacao = id_transacao;
    }

    public int getFk_usuario() {
        return fk_usuario;
    }

    public void setFk_usuario(int fk_usuario) {
        this.fk_usuario = fk_usuario;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getPlanejamento() {
        return planejamento;
    }

    public void setPlanejamento(int planejamento) {
        this.planejamento = planejamento;
    }

    public int getCarteira() {
        return carteira;
    }

    public void setCarteira(int carteira) {
        this.carteira = carteira;
    }

    public float getValor_transacao() {
        return valor_transacao;
    }

    public void setValor_transacao(float valor_transacao) {
        this.valor_transacao = valor_transacao;
    }

    public String getData_transasao() {
        return data_transasao;
    }

    public void setData_transasao(String data_transasao) {
        this.data_transasao = data_transasao;
    }

    public String getDecricao() {
        return decricao;
    }

    public void setDecricao(String decricao) {
        this.decricao = decricao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getNomeCategoria() {
        return nomeCategoria;
    }

    public void setNomeCategoria(String nomeCategoria) {
        this.nomeCategoria = nomeCategoria;
    }
}
