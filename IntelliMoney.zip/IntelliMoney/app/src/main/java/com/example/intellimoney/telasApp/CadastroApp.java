package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.criptografia.CriptografiaSenha;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Usuario;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class CadastroApp extends AppCompatActivity {

    EditText editTextNomeUsuario, editTextEmailUsuario, editTextSenhaUsuario;
    TextView txtVoltar;
    Button btnCadastrar;

    SQLiteDatabase conexao;
    IntellimoneyDAO dao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_app);

        refereniaID();
        conexao();

        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltar();
            }
        });

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    cadastrarUsuario();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }

            }
        });

    }

    private void cadastrarUsuario() throws UnsupportedEncodingException, NoSuchAlgorithmException {

        boolean camposValidados = validarCampos();

        if (camposValidados == true){

            IntellimoneyDAO dao = new IntellimoneyDAO(this); //getApplicationContext()
            CriptografiaSenha  criptografia = new CriptografiaSenha();
            Usuario usuario = new Usuario();

            String nome  = editTextNomeUsuario.getText().toString();
            String email = editTextEmailUsuario.getText().toString();
            String senha = editTextSenhaUsuario.getText().toString();

            usuario.setNome(nome);
            usuario.setEmail(email);
            usuario.setSenha(criptografia.CriptografiaSenha(senha));

            boolean checarUsuario = dao.autenticaUsuario(email, senha);
            if(checarUsuario == true){
                Toast.makeText(this, "Email existente em nossa dase de dados", Toast.LENGTH_SHORT).show();
            }else {
                boolean status = dao.cadastrarUsuario(usuario);
                if (status == true) {

                    Intent intent = new Intent(CadastroApp.this, CadastroRealizadoApp.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Erro ao cadastrar.", Toast.LENGTH_SHORT).show();
                }
            }

        } else {
            editTextNomeUsuario.setError("Digite o nome.");
            editTextEmailUsuario.setError("Digite o email.");
            editTextSenhaUsuario.setError("Digite a senha.");
            Toast.makeText(getApplicationContext(),"Preencha todos os campos antes de prosseguir.",Toast.LENGTH_LONG).show();
        }

    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if(editTextNomeUsuario.getText().toString().equals("")  ||
            editTextEmailUsuario.getText().toString().equals("") ||
            editTextSenhaUsuario.getText().toString().equals("")    ){

            camposValidados = false;
        }
        return camposValidados;
    }

    private void refereniaID() {
        editTextNomeUsuario  = findViewById(R.id.editTextNomeUsuario);
        editTextEmailUsuario = findViewById(R.id.editTextEmailUsuario);
        editTextSenhaUsuario = findViewById(R.id.editTextSenhaUsuario);
        txtVoltar            = findViewById(R.id.txtVoltar);
        btnCadastrar         = findViewById(R.id.btnCadastrar);
    }

    private void voltar(){
        Intent intent = new Intent(CadastroApp.this, LoginApp.class);
        startActivity(intent);
        finish();
    }

    private void conexao(){
        try {
            dao = new IntellimoneyDAO(this);
            conexao = dao.getWritableDatabase();

            Toast.makeText(this, "conexão criada", Toast.LENGTH_SHORT).show();

        }catch (SQLiteException e){
            Toast.makeText(this, "Erro conexão: "+e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}