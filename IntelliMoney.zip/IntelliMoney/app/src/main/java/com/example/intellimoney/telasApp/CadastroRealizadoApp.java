package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.intellimoney.AppUtil.AppUtil;
import com.example.intellimoney.R;

public class CadastroRealizadoApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_realizado_app);

        irParaPrincipal();
    }

    private void irParaPrincipal() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(CadastroRealizadoApp.this, PrincipalApp.class);
                startActivity(intent);
                finish();
                return;
            }
        }, AppUtil.TIME_SPLASH2);
    }
}