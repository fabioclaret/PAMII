package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.intellimoney.R;

public class CalculadorasApp extends AppCompatActivity {

    TextView btnVoltar, btnCalculosCLT, btnCalc_Financeiro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculadoras_app);

        referenciaID();

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarMaisOpcoes();
            }
        });

        btnCalculosCLT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCalculosCLT();
            }
        });

        btnCalc_Financeiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCalculosFinanceiros();
            }
        });
    }

    private void irParaCalculosFinanceiros() {
        Intent intent = new Intent(CalculadorasApp.this, CalculosFinanceirosApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaCalculosCLT() {
        Intent intent = new Intent(CalculadorasApp.this, CalculosCLT_App.class);
        startActivity(intent);
        finish();
    }

    private void voltarMaisOpcoes() {
        Intent intent = new Intent(CalculadorasApp.this, MaisOpcoesApp.class);
        startActivity(intent);
        finish();
    }

    private void referenciaID() {
        btnVoltar          = findViewById(R.id.txtVoltar);
        btnCalculosCLT     = findViewById(R.id.btnCalculosCLT);
        btnCalc_Financeiro = findViewById(R.id.btnCalc_Financeiro);
    }


}