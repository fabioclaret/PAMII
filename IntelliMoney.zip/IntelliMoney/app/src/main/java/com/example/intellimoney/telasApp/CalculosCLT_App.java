package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.intellimoney.R;

public class CalculosCLT_App extends AppCompatActivity {

    TextView btnVoltar, btnSalarioLiquido, btnHoraExtra, btnFerias, btnDecimoTerceiro, btnRecisao, btnFGTS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculos_clt_app);

        referenciaID();
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarCalculadorasApp();
            }
        });

        btnSalarioLiquido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnHoraExtra.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnFerias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnDecimoTerceiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnRecisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnFGTS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
    }

    private void referenciaID() {
        btnVoltar = findViewById(R.id.txtVoltar);
        btnSalarioLiquido = findViewById(R.id.btnSalarioLiquido);
        btnHoraExtra = findViewById(R.id.btnHoraExtra);
        btnDecimoTerceiro = findViewById(R.id.btnDecimoTerceiro);
        btnRecisao = findViewById(R.id.btnRecisao);
        btnFGTS = findViewById(R.id.btnFGTS);
        btnFerias = findViewById(R.id.btnFerias);
    }

    private void voltarCalculadorasApp() {
        Intent intent = new Intent(CalculosCLT_App.this, CalculadorasApp.class);
        startActivity(intent);
        finish();
    }
}