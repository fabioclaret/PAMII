package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.intellimoney.R;

public class CalculosFinanceirosApp extends AppCompatActivity {

    TextView btnVoltar,btnFinanciamento, btnJurosSimples, btnJurosComposto, btnInvestimento, btnEmprestimo, btnRendimentoPoupanca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculos_financeiros_app);

        referenciaID();
        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarCalculadorasApp();
            }
        });

        btnFinanciamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnJurosSimples.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnJurosComposto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnInvestimento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnEmprestimo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        btnRendimentoPoupanca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });
    }

    private void referenciaID() {
        btnVoltar             = findViewById(R.id.txtVoltar);
        btnFinanciamento      = findViewById(R.id.btnFinanciamento);
        btnJurosSimples       = findViewById(R.id.btnJurosSimples);
        btnJurosComposto      = findViewById(R.id.btnJurosComposto);
        btnInvestimento       = findViewById(R.id.btnInvestimento);
        btnEmprestimo         = findViewById(R.id.btnEmprestimo);
        btnRendimentoPoupanca = findViewById(R.id.btnRendimentoPoupanca);
    }

    private void voltarCalculadorasApp(){
        Intent intent = new Intent(CalculosFinanceirosApp.this, CalculadorasApp.class);
        startActivity(intent);
        finish();
    }
}