package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.criptografia.CriptografiaSenha;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.model.Usuario;

public class CriarCarteiraApp extends AppCompatActivity {
    
    TextView txtVoltar, btnCriarConta;
    EditText editTextSaldoConta, editTextNomeConta;
    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_carteira_app);
        
        referenciaID();
        
        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                criarConta();
            }
        });

        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaMinhasContas();
            }
        });
    }

    private void criarConta() {
        boolean camposValidados = validarCampos();

        if(camposValidados){

            IntellimoneyDAO dao = new IntellimoneyDAO(this); //getApplicationContext()
            CriptografiaSenha criptografia = new CriptografiaSenha();
            Carteira carteira = new Carteira();

            String nome_conta  = editTextNomeConta.getText().toString();
            float saldo = Float.parseFloat(editTextSaldoConta.getText().toString());
            int user = 1;

            carteira.setNome_carteira(nome_conta);
            carteira.setSaldo(saldo);
            carteira.setFk_usuario(user);

            boolean status = dao.criaCarteira(carteira);

            if(status){
                Toast.makeText(this, "Conta criada com sucesso!", Toast.LENGTH_SHORT).show();
                irParaMinhasContas();
            }else{
                Toast.makeText(this, "Erro ao criar conta", Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
        }

    }

    private void irParaMinhasContas(){
        Intent intent = new Intent(this, MinhasContasApp.class);
        startActivity(intent);
        finish();
    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if(editTextNomeConta.getText().toString().equals("")  ||
                editTextSaldoConta.getText().toString().equals("")){

            camposValidados = false;
        }
        return camposValidados;
    }

    private void referenciaID() {
        txtVoltar          = findViewById(R.id.txtVoltar);
        btnCriarConta      = findViewById(R.id.btnCriarConta);
        editTextSaldoConta = findViewById(R.id.editTextSaldoConta);
        editTextNomeConta  = findViewById(R.id.editTextNomeConta);
    }
}