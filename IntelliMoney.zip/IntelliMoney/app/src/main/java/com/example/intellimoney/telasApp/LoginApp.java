package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.criptografia.CriptografiaSenha;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Usuario;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class LoginApp extends AppCompatActivity {

    TextView txtCadastreSe, txtEsqueceuSenha, txtCategorias;
    EditText editTextLogin, editTextSenha;
    Button btnEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_app);

        referenciaPorID();

        txtCadastreSe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCadastro();
            }
        });

        txtEsqueceuSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRedefinirSenha();
            }
        });

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    autenticaUsuarioSenha();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
        });

        txtCategorias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCategorias();
            }
        });
    }

    private void autenticaUsuarioSenha() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        CriptografiaSenha criptografiaSenha = new CriptografiaSenha();

        boolean camposValidados = validarCampos();
        String email = editTextLogin.getText().toString();
        String senha = criptografiaSenha.CriptografiaSenha(editTextSenha.getText().toString());

        dao.buscarUsuario(email, senha);
        if (camposValidados){
            boolean checarUsuario = dao.autenticaUsuario(email, senha);
            if(checarUsuario){

                irParaPrincipal();

            }else{
                Toast.makeText(this, "Cadastro não existe.", Toast.LENGTH_SHORT).show();
            }

        } else {
            editTextLogin.setError("Digite o email");
            editTextSenha.setError("Digite o a senha");
            Toast.makeText(getApplicationContext(),"Preencha todos os campos antes de prosseguir.",Toast.LENGTH_LONG).show();        }
    }

    private void irParaCadastro(){
        Intent intent = new Intent(LoginApp.this, CadastroApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaRedefinirSenha(){
        Intent intent = new Intent(LoginApp.this, RedefinirSenhaApp.class);
        startActivity(intent);
        finish();
    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if (editTextLogin.getText().toString().equals("") ||
                editTextSenha.getText().toString().equals("")){
            camposValidados = false;
        }
        return camposValidados;
    }

    private void referenciaPorID(){
        editTextLogin    = findViewById(R.id.editTextLogin);
        editTextSenha    = findViewById(R.id.editTextSenha);
        txtCadastreSe    = findViewById(R.id.txtCadastreSe);
        txtEsqueceuSenha = findViewById(R.id.txtEsqueceuSenha);
        btnEntrar        = findViewById(R.id.btnEntrar);

        txtCategorias = findViewById(R.id.txtCategorias);
    }

    private void irParaCategorias() {
        Intent intent = new Intent(this, TELA_PROVISORIA_CADASTRO_CATEGORIAS.class);
        startActivity(intent);
        finish();
    }
    private void irParaPrincipal(){
        Intent intent = new Intent(this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

}