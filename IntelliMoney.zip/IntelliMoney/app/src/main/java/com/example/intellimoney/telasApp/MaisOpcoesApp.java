package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.intellimoney.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MaisOpcoesApp extends AppCompatActivity {

    TextView btnPrincipal, btnTransacoes, btnPlanejamento, btnMaisOpcoes, btnObjetivos, btnCalculadoras, txtReceita, txtDespesa;
    ImageView btnAtalhoMais, btnAtalhoMais1;
    View botaoMais;
    FloatingActionButton actionButtonReceita, actionButtonDespesa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mais_opcoes_app);

        referenciaID();

        btnPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaPrincipal();
            }
        });

        btnTransacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaTransacoes();
            }
        });

        btnPlanejamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // irParaPlanejamento();
            }
        });

        btnObjetivos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaObjetivos();
            }
        });

        btnCalculadoras.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCalculadoras();
            }
        });

        btnAtalhoMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                escolherOpcaoReceitaEDespesa();
            }
        });

        btnAtalhoMais1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarPrincipal();
            }
        });

        actionButtonDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarSaida();
            }
        });

        actionButtonReceita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarEntrada();
            }
        });
    }

    private void irParaPrincipal() {
        Intent intent = new Intent(MaisOpcoesApp.this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaObjetivos() {
        Intent intent = new Intent(MaisOpcoesApp.this, ObjetivosApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaCalculadoras() {
        Intent intent = new Intent(MaisOpcoesApp.this, CalculadorasApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaTransacoes() {
        Intent intent = new Intent(MaisOpcoesApp.this, TransacoesApp.class);
        startActivity(intent);
        finish();
    }

    /* private void irParaPlanejamento() {
        Intent intent = new Intent(TransacoesApp.this, PlanejamentoApp.class);
        startActivity(intent);
        finish();
    }
    */

    private void irParaRegistrarSaida(){
        Intent intent = new Intent(MaisOpcoesApp.this, RegistrarSaidaApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaRegistrarEntrada(){
        Intent intent = new Intent(MaisOpcoesApp.this, RegistrarEntradaApp.class);
        startActivity(intent);
        finish();
    }


    @SuppressLint("WrongConstant")
    public void escolherOpcaoReceitaEDespesa(){
        int i = 1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);
    }

    @SuppressLint("WrongConstant")
    public void voltarPrincipal(){
        int i = -1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);

    }

    private void referenciaID() {
        btnPrincipal         = findViewById(R.id.txtPrincipal);
        btnTransacoes        = findViewById(R.id.txtTransacoes);
        btnPlanejamento      = findViewById(R.id.txtPlanejamento);
        btnMaisOpcoes        = findViewById(R.id.txtMaisOpcoes);
        btnObjetivos         = findViewById(R.id.btnObjetivos);
        btnCalculadoras      = findViewById(R.id.btnCalculadoras);
        botaoMais            = findViewById(R.id.viewBotaoMais);
        actionButtonReceita  = findViewById(R.id.actionButtonReceita);
        actionButtonDespesa  = findViewById(R.id.actionButtonDespesa);
        txtReceita           = findViewById(R.id.txtReceita);
        txtDespesa           = findViewById(R.id.txtDespesa);
        btnAtalhoMais        = findViewById(R.id.btnAtalhoMais);
        btnAtalhoMais1       = findViewById(R.id.btnAtalhoMais1);
    }
}