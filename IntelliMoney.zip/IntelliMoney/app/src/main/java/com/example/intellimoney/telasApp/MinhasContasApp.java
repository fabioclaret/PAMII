package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.helper.RecyclerItemClickListener;
import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.adapter.CarteiraAdapter;

import java.util.ArrayList;
import java.util.List;

public class MinhasContasApp extends AppCompatActivity {

    TextView txtVoltar;
    ImageView btnCriarConta;
    RecyclerView recyclerViewMinhasContas;
    List<Carteira> listaCarteiras = new ArrayList<>();
    CarteiraAdapter carteiraAdapter;
    IntellimoneyDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_minhas_contas_app);

        referenciaID();
        eventoClickRecycleView();



        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaPrincipal();
            }
        });

        btnCriarConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaCriarConta();
            }
        });
    }

    @Override
    protected void onStart() {
        visualizarContas();
        super.onStart();
    }

    private void visualizarContas() {

        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        listaCarteiras = dao.listarContas();


        // CONFIGURAR ADAPTER
        carteiraAdapter = new CarteiraAdapter(listaCarteiras);

        // CONFIGURAR O RECYCLERVIEW
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerViewMinhasContas.setLayoutManager(layoutManager);
        recyclerViewMinhasContas.setHasFixedSize(true);
        recyclerViewMinhasContas.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
        recyclerViewMinhasContas.setAdapter(carteiraAdapter);
    }

    private void irParaCriarConta() {
        Intent intent = new Intent(this, CriarCarteiraApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaPrincipal() {
        Intent intent = new Intent(this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

    private void referenciaID() {
        btnCriarConta            = findViewById(R.id.btnAdicionarConta);
        txtVoltar                = findViewById(R.id.txtVoltar);
        recyclerViewMinhasContas = findViewById(R.id.recycleMinhasContas);
    }

    private void eventoClickRecycleView(){
        recyclerViewMinhasContas.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        getApplicationContext(),
                        recyclerViewMinhasContas,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                Log.i("clique", "onItemClick: onItemClick");
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {
                                Log.i("clique", "onItemClick: onLingItemClick");
                            }

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                            }
                        }
                )
        );
    }

    private void listarContas(){
        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        listaCarteiras = dao.listarContas();

        //listViewMinhasContas.setAdapter(adapter);
    }
}