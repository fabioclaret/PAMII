package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Objetivo;

public class ObjetivosApp extends AppCompatActivity {

    EditText valorObjetivo, nomeObjetivo, valorInicialObjetivo, descricaoObjetivo, dataObjetivo;
    TextView btnConfirmarObjetivo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_objetivos_app);

        referenciaID();

        btnConfirmarObjetivo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                criarObjetivo();
            }
        });
    }

    private void criarObjetivo(){
        boolean camposValidados = validarCampos();

        if(camposValidados){
            Objetivo objetivo = new Objetivo();
            IntellimoneyDAO dao = new IntellimoneyDAO(this);

            String nome_objetivo     = nomeObjetivo.getText().toString();
            String data_objetivo     = dataObjetivo.getText().toString();
            String descicao_objetivo = descricaoObjetivo.getText().toString();
            float  valor_objetivo    = Float.parseFloat(valorObjetivo.getText().toString());
            float  valor_inicial     = Float.parseFloat(valorInicialObjetivo.getText().toString());
            int usuario              = 1;

            objetivo.setValor_objetivo(valor_objetivo);
            objetivo.setValor_deposito(valor_inicial);
            objetivo.setNome_objetivo(nome_objetivo);
            objetivo.setData_objetivo(data_objetivo);
            objetivo.setDescricao(descicao_objetivo);
            objetivo.setUsuario(usuario);

            dao.insereObjetivo(objetivo);

            //mostrarObjetivo();

            Toast.makeText(this, "Objetivo cadastrado", Toast.LENGTH_SHORT).show();
        }

    }

    private  boolean validarCampos(){

        if(!valorObjetivo.getText().toString().equals("")){
            if(!valorInicialObjetivo.getText().toString().equals("")){
                if(!nomeObjetivo.getText().toString().equals("")){
                    if(!dataObjetivo.getText().toString().equals("")){
                        if(!descricaoObjetivo.getText().toString().equals("")){
                            return true;
                        }else{
                            Toast.makeText(this, "Descrição do objetivo vazio.", Toast.LENGTH_SHORT).show();
                            return false;
                        }
                    }else{
                        Toast.makeText(this, "Data do objetivo vazio.", Toast.LENGTH_SHORT).show();
                        return false;
                    }
                }else{
                    Toast.makeText(this, "Nome do objetivo vazio.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }else{
                Toast.makeText(this, "Valor inicial do objetivo vazio.", Toast.LENGTH_SHORT).show();
                return false;
            }
        }else{
            Toast.makeText(this, "Valor do objetivo vazio.", Toast.LENGTH_SHORT).show();
            return false;
        }

    }

    private void mostrarObjetivo(){
       /* Intent intent = new Intent(this, MostrarObjetivoApp.class);
        startActivity(intent);
        finish();
        */
    }

    private void referenciaID() {
        btnConfirmarObjetivo = findViewById(R.id.btnConfirmarObjetivo);
        valorInicialObjetivo = findViewById(R.id.editTextValorInicialObjetivo);
        descricaoObjetivo    = findViewById(R.id.editTextDescricaoObjetivo);
        valorObjetivo        = findViewById(R.id.editTextValorObjetivo);
        nomeObjetivo         = findViewById(R.id.editTextNomeObjetivo);
        dataObjetivo         = findViewById(R.id.editTextDataObjetivo);
    }
}