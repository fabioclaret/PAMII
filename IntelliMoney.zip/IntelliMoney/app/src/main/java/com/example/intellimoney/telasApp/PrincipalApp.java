package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.model.Usuario;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class PrincipalApp extends AppCompatActivity {

    TextView btnMeuPerfil, btnPrincipal, btnTransacoes, btnPlanejamento, btnMaisOpcoes, txtSaldoDespesa, txtSaldoReceita, txtReceita, txtDespesa, txtSaldoEmConta;
    ImageView btnAtalhoMais, btnAtalhoMais1;
    FloatingActionButton actionButtonDespesa, actionButtonReceita;
    View botaoMais;

    Usuario usuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_app);

        referenciaID();
       // mostrarValores();

        int id = usuario.getId_usuario();
        String nome = usuario.getNome();
        String email = usuario.getEmail();
        Log.i("teste", "onCreate: "+ id+", "+nome+", "+email);

        btnMeuPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaVisualizarPerfil();
            }
        });

        btnMaisOpcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaMaisOpcoes();
            }
        });

        btnTransacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaTransacoes();
            }
        });

        btnPlanejamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //irParaPlanejamento();
            }
        });

        txtSaldoDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaTransacoes();
            }
        });

        txtSaldoReceita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaTransacoes();
            }
        });

        btnAtalhoMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                escolherOpcaoReceitaEDespesa();
            }
        });

        btnAtalhoMais1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarPrincipal();
            }
        });

        actionButtonDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarSaida();
            }
        });

        actionButtonReceita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarEntrada();
            }
        });

        txtSaldoEmConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaMinhasContas();
            }
        });

    }

    private void irParaVisualizarPerfil() {
        Intent intent = new Intent(PrincipalApp.this, VisualizarPerfilApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaMaisOpcoes() {
        Intent intent = new Intent(PrincipalApp.this, MaisOpcoesApp.class);
        startActivity(intent);
        finish();
    }


    private void irParaTransacoes() {
        Intent intent = new Intent(PrincipalApp.this, TransacoesApp.class);
        startActivity(intent);
        finish();
    }

    /* private void irParaPlanejamento() {
        Intent intent = new Intent(TransacoesApp.this, PlanejamentoApp.class);
        startActivity(intent);
        finish();
    }
    */

    private void irParaRegistrarSaida(){
        Intent intent = new Intent(PrincipalApp.this, RegistrarSaidaApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaRegistrarEntrada(){
        Intent intent = new Intent(PrincipalApp.this, RegistrarEntradaApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaMinhasContas(){
        Intent intent = new Intent(this, MinhasContasApp.class);
        startActivity(intent);
        finish();
    }

    private void mostrarValores(){
        Carteira carteira = new Carteira();
        IntellimoneyDAO dao = new IntellimoneyDAO(this);

        dao.listarContas();

        txtSaldoEmConta.setText(String.valueOf(carteira.getSaldo()));
    }


    @SuppressLint("WrongConstant")
    public void escolherOpcaoReceitaEDespesa(){
        int i = 1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);
    }

    @SuppressLint("WrongConstant")
    public void voltarPrincipal(){
        int i = -1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);

    }

    private void referenciaID() {
        btnMeuPerfil         = findViewById(R.id.btnMeuPerfil);
        btnPrincipal         = findViewById(R.id.txtPrincipal);
        btnTransacoes        = findViewById(R.id.txtTransacoes);
        btnPlanejamento      = findViewById(R.id.txtPlanejamento);
        btnMaisOpcoes        = findViewById(R.id.txtMaisOpcoes);
        btnAtalhoMais        = findViewById(R.id.btnAtalhoMais);
        btnAtalhoMais1       = findViewById(R.id.btnAtalhoMais1);
        txtSaldoDespesa      = findViewById(R.id.txtSaldoDespesa);
        txtSaldoReceita      = findViewById(R.id.txtSaldoReceita);
        botaoMais            = findViewById(R.id.viewBotaoMais);
        actionButtonReceita  = findViewById(R.id.actionButtonReceita);
        actionButtonDespesa  = findViewById(R.id.actionButtonDespesa);
        txtReceita           = findViewById(R.id.txtReceita);
        txtDespesa           = findViewById(R.id.txtDespesa);
        txtSaldoEmConta      = findViewById(R.id.txtSaldoEmConta);
    }
}