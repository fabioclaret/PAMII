package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.criptografia.CriptografiaSenha;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Usuario;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;

public class RedefinirSenhaApp extends AppCompatActivity {

    EditText editTextNovaSenha, editTextRepetirSenha, editTextEmailRedSenha;
    TextView txtVoltar;
    Button btnRedefinirSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_redefinir_senha_app);

        refernciaID();

        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarTelaLogin();
            }
        });

        btnRedefinirSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    redefinirSenha();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                } catch (NoSuchAlgorithmException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void redefinirSenha() throws UnsupportedEncodingException, NoSuchAlgorithmException {
        boolean camposValidads = validarCampos();
        Usuario usuario = new Usuario();
        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        CriptografiaSenha criptografia = new CriptografiaSenha();

        String email        = editTextEmailRedSenha.getText().toString();
        String novaSenha    = editTextNovaSenha.getText().toString();
        String repetirSenha = editTextRepetirSenha.getText().toString();

        if (camposValidads){
            if(repetirSenha.equals(novaSenha)){
                usuario.setEmail(email);
                usuario.setSenha(criptografia.CriptografiaSenha(novaSenha));

                boolean statusRedefinir = dao.redefinirSenha(usuario);

                if (statusRedefinir){

                    Toast.makeText(this, "Senha redefinida com sucesso!", Toast.LENGTH_SHORT).show();
                    voltarTelaLogin();

                }else{
                    Toast.makeText(this, "Erro ao redefinir a senha.", Toast.LENGTH_SHORT).show();
                }
            }else{
                editTextRepetirSenha.setError("Por favor, repita a mesma senha.");
            }

        }else {
            editTextEmailRedSenha.setError("Digite o email para redefinir senha.");
            editTextNovaSenha.setError("Digite a nova senha.");
            editTextRepetirSenha.setError("Repita a senha.");
            Toast.makeText(getApplicationContext(),"Preencha todos os campos antes de prosseguir.",Toast.LENGTH_LONG).show();

        }
    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if(editTextNovaSenha.getText().toString().equals("")  ||
                editTextRepetirSenha.getText().toString().equals("")){

            camposValidados = false;
        }
        return camposValidados;
    }

    private void refernciaID() {
        editTextNovaSenha     = findViewById(R.id.editTextNovaSenha);
        editTextRepetirSenha  = findViewById(R.id.editTextRepetirSenha);
        editTextEmailRedSenha = findViewById(R.id.editTextEmailRedSenha);
        txtVoltar             = findViewById(R.id.txtVoltar);
        btnRedefinirSenha     = findViewById(R.id.btnRedefinirSenha);
    }

    private void voltarTelaLogin(){
        Intent intent = new Intent(RedefinirSenhaApp.this, LoginApp.class);
        startActivity(intent);
        finish();
    }
}