package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.helper.DateCustom;
import com.example.intellimoney.model.Transacoes;

public class RegistrarEntradaApp extends AppCompatActivity {

    TextView txtVoltar, btnRegistrarEntrada;
    EditText editTextValorReceita, editTextDescricaoReceita, editTextCategoriaReceita, editTextDataReceita, editTextCarteira;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_entrada);



        referenciaID();

        editTextDataReceita.setText(DateCustom.dataAtual());



        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaPrincipal();
            }
        });

        btnRegistrarEntrada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                inserirEntrada();
            }
        });
    }

    private void inserirEntrada() {
        boolean camposValidados = validarCampos();

        if (camposValidados){

            IntellimoneyDAO dao = new IntellimoneyDAO(this); //getApplicationContext()
            Transacoes transacoes = new Transacoes();

            float valorDespesa   = Float.parseFloat(editTextValorReceita.getText().toString());
            String data          = editTextDataReceita.getText().toString();
            String descricao     = editTextDescricaoReceita.getText().toString();
            String tipo          = "Receita";
            int categoria        = Integer.parseInt(editTextCategoriaReceita.getText().toString());
            int carteira         = Integer.parseInt(editTextCarteira.getText().toString());
            int usuario          = 1;


            transacoes.setValor_transacao(valorDespesa);
            transacoes.setDecricao(descricao);
            transacoes.setData_transasao(data);
            transacoes.setCarteira(carteira);
            transacoes.setCategoria(categoria);
            transacoes.setFk_usuario(usuario);
            transacoes.setTipo(tipo);

            dao.insereReceita(transacoes);

            irParaTransacoes();

        } else {
            Toast.makeText(getApplicationContext(),"Preencha todos os campos antes de prosseguir.",Toast.LENGTH_LONG).show();
        }

    }
    private void irParaTransacoes() {
        Intent intent = new Intent(this, TransacoesApp.class);
        startActivity(intent);
    }

    private void irParaPrincipal() {
        Intent intent = new Intent(RegistrarEntradaApp.this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if(editTextValorReceita.getText().toString().equals("")          ||
                editTextDataReceita.getText().toString().equals("")      ||
                editTextCarteira.getText().toString().equals("")         ||
                editTextDescricaoReceita.getText().toString().equals("") ||
                editTextCategoriaReceita.getText().toString().equals("")){

            camposValidados = false;
        }
        return camposValidados;
    }

    private void referenciaID() {
        txtVoltar                = findViewById(R.id.txtVoltar);
        editTextValorReceita     = findViewById(R.id.editTextValorReceita);
        editTextDescricaoReceita = findViewById(R.id.editTextDescricaoReceita);
        editTextCategoriaReceita = findViewById(R.id.editTextCategoriaReceita);
        editTextDataReceita      = findViewById(R.id.editTextDataReceita);
        editTextCarteira         = findViewById(R.id.editTextCarteiraReceita);
        btnRegistrarEntrada      = findViewById(R.id.btnConfirmarEntrada);

    }
}