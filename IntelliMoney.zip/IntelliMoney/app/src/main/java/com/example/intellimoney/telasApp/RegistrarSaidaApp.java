package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.helper.DateCustom;
import com.example.intellimoney.model.Transacoes;
import com.example.intellimoney.model.Usuario;

public class RegistrarSaidaApp extends AppCompatActivity {

    TextView txtVoltar, confirmarDespesa;
    EditText editValorDespesa, carteiraDespesa, categoriaDespesa, dataDespesa, descricaoDespesa;

    Usuario usuario = new Usuario();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_saida_app);

        referenciaID();

        dataDespesa.setText(DateCustom.dataAtual());
        int resultado = usuario.getId_usuario();
        Log.i("teste", "onCreate: "+ resultado);




        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaPrincipal();
            }
        });

        confirmarDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registrarDespesa();
            }
        });
    }

    private void carregarCampos(){
        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        Transacoes transacoes = new Transacoes();
        dao.listarTransacoes();

        dataDespesa.setText(transacoes.getData_transasao());
        editValorDespesa.setText(String.valueOf(transacoes.getValor_transacao()));
        carteiraDespesa.setText(transacoes.getCarteira());
        categoriaDespesa.setText(transacoes.getCategoria());
        descricaoDespesa.setText(transacoes.getDecricao());

    }

    private void registrarDespesa(){

        boolean camposValidados = validarCampos();

        if (camposValidados){

            IntellimoneyDAO dao = new IntellimoneyDAO(this); //getApplicationContext()
            Transacoes transacoes = new Transacoes();
            Usuario usuario = new Usuario();

            float valorDespesa   = Float.parseFloat(editValorDespesa.getText().toString());
            String data          = dataDespesa.getText().toString();
            String descricao     = descricaoDespesa.getText().toString();
            String tipo          = "Despesa";
            int categoria        = Integer.parseInt(categoriaDespesa.getText().toString());
            int carteira         = Integer.parseInt(carteiraDespesa.getText().toString());
            int fkUsuario        = usuario.getId_usuario();


            transacoes.setValor_transacao(valorDespesa);
            transacoes.setDecricao(descricao);
            transacoes.setData_transasao(data);
            transacoes.setCarteira(carteira);
            transacoes.setCategoria(categoria);
            transacoes.setFk_usuario(fkUsuario);
            transacoes.setTipo(tipo);

            dao.insereDespesa(transacoes);
            irParaTransacoes();

        } else {
            Toast.makeText(getApplicationContext(),"Preencha todos os campos antes de prosseguir.",Toast.LENGTH_LONG).show();
        }

    }

    private void irParaTransacoes() {
        Intent intent = new Intent(this, TransacoesApp.class);
        startActivity(intent);
    }

    private void irParaPrincipal() {
        Intent intent = new Intent(RegistrarSaidaApp.this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

    private  boolean validarCampos(){
        boolean camposValidados = true;

        if(editValorDespesa.getText().toString().equals("")   ||
                dataDespesa.getText().toString().equals("")      ||
                carteiraDespesa.getText().toString().equals("")  ||
                descricaoDespesa.getText().toString().equals("") ||
                categoriaDespesa.getText().toString().equals("")){

            camposValidados = false;
        }
        return camposValidados;
    }


    private void referenciaID() {
        txtVoltar        = findViewById(R.id.txtVoltar);
        dataDespesa      = findViewById(R.id.editTextDataDespesa);
        editValorDespesa = findViewById(R.id.editTextValorReceita);
        carteiraDespesa  = findViewById(R.id.editTextCarteiraDespesa);
        categoriaDespesa = findViewById(R.id.editTextCategoriaDespesa);
        descricaoDespesa = findViewById(R.id.editTextDescricaoDespesa);
        confirmarDespesa = findViewById(R.id.btnConfirmarDespesa);
    }
}