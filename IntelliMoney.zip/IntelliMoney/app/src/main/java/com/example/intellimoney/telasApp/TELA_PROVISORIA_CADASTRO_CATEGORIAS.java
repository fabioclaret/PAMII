package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.intellimoney.R;
import com.example.intellimoney.criptografia.CriptografiaSenha;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Categorias;
import com.example.intellimoney.model.Usuario;

public class TELA_PROVISORIA_CADASTRO_CATEGORIAS extends AppCompatActivity {

    TextView voltar;
    EditText editCategoria, editTipoCategoria;
    Button btnEntrada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_provisoria_cadastro_categorias);

        editCategoria = findViewById(R.id.editCategoria);
        editTipoCategoria = findViewById(R.id.editTextTipoCartegoria);
        btnEntrada = findViewById(R.id.btnCategoriaEntrada);
        voltar = findViewById(R.id.txtVoltar);


        btnEntrada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insereCategoria();
            }
        });

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(TELA_PROVISORIA_CADASTRO_CATEGORIAS.this, LoginApp.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void insereCategoria() {
        IntellimoneyDAO dao = new IntellimoneyDAO(this); //getApplicationContext()
        Categorias categorias = new Categorias();

        String categoria  = editCategoria.getText().toString();
        String tipo_categoria  = editTipoCategoria.getText().toString();

        categorias.setNome_categoria(categoria);
        categorias.setTipo_categoria(tipo_categoria);


        boolean status = dao.insereCategorias(categorias);
        if(status == true){
            Toast.makeText(this, "Categoria salva", Toast.LENGTH_SHORT).show();
        }else {

                Toast.makeText(this, "Erro ao cadastrar.", Toast.LENGTH_SHORT).show();
        }
    }


}