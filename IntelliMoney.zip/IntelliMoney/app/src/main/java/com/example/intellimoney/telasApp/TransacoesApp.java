package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.intellimoney.R;
import com.example.intellimoney.adapter.CarteiraAdapter;
import com.example.intellimoney.adapter.TransacaoAdapter;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.helper.RecyclerItemClickListener;
import com.example.intellimoney.model.Carteira;
import com.example.intellimoney.model.Transacoes;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class TransacoesApp extends AppCompatActivity {

    TextView btnPrincipal, btnPlanejamento, btnMaisOpcoes, txtReceita, txtDespesa, txtSaldoAtualTransacoes, txtTotalGastosTransacoes;
    ImageView btnAtalhoMais, btnAtalhoMais1;
    View botaoMais;
    RecyclerView recyclerViewTransacoes;
    FloatingActionButton actionButtonDespesa, actionButtonReceita;

    List<Transacoes> listaTransacoes = new ArrayList<>();
    TransacaoAdapter transacaoAdapter;

    Transacoes transacoes = new Transacoes();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transacoes_app);

        referenciaID();
        eventoClickRecycleView();



        btnPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaPrincipal();
            }
        });

        btnPlanejamento.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //irParaPlanejamento();
            }
        });

        btnMaisOpcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaMaisOpcoes();
            }
        });

        btnAtalhoMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                escolherOpcaoReceitaEDespesa();
            }
        });

        btnAtalhoMais1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                voltarPrincipal();
            }
        });

        actionButtonDespesa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarSaida();
            }
        });

        actionButtonReceita.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irParaRegistrarEntrada();
            }
        });
    }

    @Override
    protected void onStart() {
        visualizarTransacoes();

        String nome = transacoes.getDecricao();
        String daTa = transacoes.getData_transasao();
        String tiPo = transacoes.getTipo();
        int categoriA = transacoes.getCategoria();
        int carteirA = transacoes.getCarteira();
        int usuariO = transacoes.getFk_usuario();
        float valor = transacoes.getValor_transacao();

        Log.i("teste", "onStart: "+nome+", "+daTa+", "+tiPo+", "+categoriA+", "+carteirA+", "+usuariO+", "+valor);
        super.onStart();
    }

    private void visualizarTransacoes() {
        IntellimoneyDAO dao = new IntellimoneyDAO(this);
        listaTransacoes = dao.listarTransacoes();

        // CONFIGURAR ADAPTER
        transacaoAdapter = new TransacaoAdapter(listaTransacoes);

        // CONFIGURAR O RECYCLERVIEW
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerViewTransacoes.setLayoutManager(layoutManager);
        recyclerViewTransacoes.setHasFixedSize(true);
        recyclerViewTransacoes.addItemDecoration(new DividerItemDecoration(this, LinearLayout.VERTICAL));
        recyclerViewTransacoes.setAdapter(transacaoAdapter);

    }

    private void irParaMaisOpcoes() {
        Intent intent = new Intent(TransacoesApp.this, MaisOpcoesApp.class);
        startActivity(intent);
        finish();
    }

   /* private void irParaPlanejamento() {
        Intent intent = new Intent(TransacoesApp.this, PlanejamentoApp.class);
        startActivity(intent);
        finish();
    }
    */

    private void irParaPrincipal() {
        Intent intent = new Intent(TransacoesApp.this, PrincipalApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaRegistrarSaida(){
        Intent intent = new Intent(TransacoesApp.this, RegistrarSaidaApp.class);
        startActivity(intent);
        finish();
    }

    private void irParaRegistrarEntrada(){
        Intent intent = new Intent(TransacoesApp.this, RegistrarEntradaApp.class);
        startActivity(intent);
        finish();
    }

    private void eventoClickRecycleView(){
        recyclerViewTransacoes.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        getApplicationContext(),
                        recyclerViewTransacoes,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                // Recuperar Transação para edição
                                Transacoes transacaoSelecionada = listaTransacoes.get(position);

                                // Enviar transação para a tela de atualização
                                Intent intent = new Intent(TransacoesApp.this, RegistrarEntradaApp.class);
                                intent.putExtra("transacaoSelecionada", transacaoSelecionada);

                                startActivity(intent);
                            }

                            @Override
                            public void onLongItemClick(View view, int position) {
                                Log.i("clique", "onItemClick: onLingItemClick");
                            }

                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                            }
                        }
                )
        );
    }



    @SuppressLint("WrongConstant")
    public void escolherOpcaoReceitaEDespesa(){
        int i = 1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);
    }

    @SuppressLint("WrongConstant")
    public void voltarPrincipal(){
        int i = -1;
        botaoMais.setVisibility(i);
        actionButtonDespesa.setVisibility(i);
        actionButtonReceita.setVisibility(i);
        txtDespesa.setVisibility(i);
        txtReceita.setVisibility(i);
        btnAtalhoMais1.setVisibility(i);

    }

    private void referenciaID() {
        btnPrincipal             = findViewById(R.id.txtPrincipal);
        btnPlanejamento          = findViewById(R.id.txtPlanejamento);
        btnMaisOpcoes            = findViewById(R.id.txtMaisOpcoes);
        recyclerViewTransacoes   = findViewById(R.id.recyclerViewTransacoes);
        botaoMais                = findViewById(R.id.viewBotaoMais);
        actionButtonReceita      = findViewById(R.id.actionButtonReceita);
        actionButtonDespesa      = findViewById(R.id.actionButtonDespesa);
        txtSaldoAtualTransacoes  = findViewById(R.id.txtSaldoAtualTransacoes);
        txtTotalGastosTransacoes = findViewById(R.id.txtTotalGastosTransacoes);
        txtReceita               = findViewById(R.id.txtReceita);
        txtDespesa               = findViewById(R.id.txtDespesa);
        btnAtalhoMais            = findViewById(R.id.btnAtalhoMais);
        btnAtalhoMais1           = findViewById(R.id.btnAtalhoMais1);
    }
}