package com.example.intellimoney.telasApp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.intellimoney.R;
import com.example.intellimoney.dao.IntellimoneyDAO;
import com.example.intellimoney.model.Usuario;

public class VisualizarPerfilApp extends AppCompatActivity {

    TextView txtVoltar, btnMeuCadastro, btnEncerrarSessao, txtTemCerteza, txtNomeUsuario, txtEmailUsuario;
    View viewParseBlack, viewConfirmarSair;
    Button btnSimSair, btnNaoSair;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_perfil_app);

        referenciarPeloID();
        voltarTelaPerfil();
        confirmEncerrarSessao();


        txtVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VisualizarPerfilApp.this, PrincipalApp.class);
                startActivity(intent);
                finish();
            }
        });

        btnEncerrarSessao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                encerrarSessao();
            }
        });

    }

    private void referenciarPeloID() {
        btnEncerrarSessao = findViewById(R.id.btnEncerrarSessao);
        btnMeuCadastro    = findViewById(R.id.btnMeuCadastro);
        txtVoltar         = findViewById(R.id.txtVoltarTelaPrincipal);
        txtTemCerteza     = findViewById(R.id.txtTemCerteza);
        txtNomeUsuario    = findViewById(R.id.txtNomeUsuario);
        txtEmailUsuario   = findViewById(R.id.txtEmailUsuario);
        viewConfirmarSair = findViewById(R.id.viewConfirmarSair);
        viewParseBlack    = findViewById(R.id.viewParseBlack);
        btnNaoSair        = findViewById(R.id.btnNaoSair);
        btnSimSair        = findViewById(R.id.btnSimSair);
    }

    @SuppressLint("WrongConstant")
    public void encerrarSessao(){
        int i = 1;
        viewParseBlack.setVisibility(i);
        viewConfirmarSair.setVisibility(i);
        txtTemCerteza.setVisibility(i);
        btnSimSair.setVisibility(i);
        btnNaoSair.setVisibility(i);
    }

    @SuppressLint("WrongConstant")
    public void voltarTelaPerfil(){
        btnNaoSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int i = -1;
                viewParseBlack.setVisibility(i);
                viewConfirmarSair.setVisibility(i);
                txtTemCerteza.setVisibility(i);
                btnSimSair.setVisibility(i);
                btnNaoSair.setVisibility(i);
            }
        });
    }

    @SuppressLint("WrongConstant")
    public void confirmEncerrarSessao(){
        btnSimSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VisualizarPerfilApp.this, SaindoApp.class);
                startActivity(intent);
                finish();
            }
        });
    }


}