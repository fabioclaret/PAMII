package com.example.loginmvc.api;

public class AppUtil {
    public static final String TAG = "projeto";
}
