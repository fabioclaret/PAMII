package com.example.loginmvc.controller;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;

import com.example.loginmvc.api.AppUtil;
import com.example.loginmvc.datamodel.UsuarioDataModel;
import com.example.loginmvc.datasource.AppDataBase;
import com.example.loginmvc.model.Usuario;

import java.util.ArrayList;
import java.util.List;

public class UsuarioController extends AppDataBase implements iCrud<Usuario>{
    ContentValues dadosDoObjeto;
    public UsuarioController(Context context) {
        super(context);
        Log.i(AppUtil.TAG, "ClienteController: Conectado ao banco");
    }

    @Override
    public boolean incluir(Usuario obj) {
        dadosDoObjeto = new ContentValues();
        dadosDoObjeto.put(UsuarioDataModel.NOME, obj.getNome());
        dadosDoObjeto.put(UsuarioDataModel.EMAIL, obj.getEmail());
        return  insert(UsuarioDataModel.TABELA, dadosDoObjeto);
    }

    @Override
    public boolean alterar(Usuario obj) {
        dadosDoObjeto = new ContentValues();
        dadosDoObjeto.put(UsuarioDataModel.NOME, obj.getNome());
        dadosDoObjeto.put(UsuarioDataModel.EMAIL, obj.getEmail());
        return true;
    }

    @Override
    public boolean deletar(Usuario obj) {
        return false;
    }

    @Override
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();

       return lista;

    }

    public boolean usuarioeSenha(String username, String password){

        return checkUserPassword(username,password);
    }

    public boolean usuario(String user) {
        return checkUser(user);
    }
}
