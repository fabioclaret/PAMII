package com.example.loginmvc.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.loginmvc.R;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}