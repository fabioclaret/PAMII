package com.example.loginmvc.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.loginmvc.R;
import com.example.loginmvc.controller.UsuarioController;
import com.example.loginmvc.model.Usuario;

public class LoginActivity extends AppCompatActivity {
    EditText userName, password, rePassword;
    Button btnLogin;
    UsuarioController controller;
    Usuario usuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initComponents();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                controller = new UsuarioController(getApplicationContext());
                usuario = new Usuario();

                String user = userName.getText().toString();
                String pass = password.getText().toString();
                String repass = rePassword.getText().toString();

                usuario.setEmail(user);
                usuario.setNome(pass);

                if (user.equals("") || pass.equals("") || repass.equals("")) {
                    Toast.makeText(getApplicationContext(), "Voce tem que preencher todos os campos;", Toast.LENGTH_SHORT).show();
                } else {
                    if (pass.equals(repass)) {
                        controller = new UsuarioController(getApplication());
                        boolean isCheckUser = controller.usuario(user);

                        if (!isCheckUser) {
                            boolean isInsert = controller.incluir(usuario);
                            if (isInsert) {
                                Toast.makeText(getApplicationContext(), "Usuario Cadastrado com Sucesso!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                                startActivity(intent);
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Usuario Já Cadastrado, nao posso incluir", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "As senhas digitadas nao sao iguais!", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        controller = new UsuarioController(getApplicationContext());
        usuario = new Usuario();

        String user = userName.getText().toString();
        String pass = password.getText().toString();
        String repass = rePassword.getText().toString();

        usuario.setEmail(user);
        usuario.setNome(pass);

        if (user.equals("") || pass.equals("") || repass.equals("")) {
            Toast.makeText(getApplicationContext(), "Voce tem que preencher todos os campos;", Toast.LENGTH_SHORT).show();
        } else {
            if (pass.equals(repass)) {
                controller = new UsuarioController(getApplication());
                boolean isCheckUser = controller.usuario(user);

                if (!isCheckUser) {
                    boolean isInsert = controller.incluir(usuario);
                    if (isInsert) {
                        Toast.makeText(getApplicationContext(), "Usuario Cadastrado com Sucesso!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                        startActivity(intent);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Usuario Já Cadastrado, nao posso incluir", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "As senhas digitadas nao sao iguais!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void initComponents() {
        userName = findViewById(R.id.user_name);
        password = findViewById(R.id.password);
        rePassword = findViewById(R.id.re_password);
        btnLogin = findViewById(R.id.btn_signin);

    }
}