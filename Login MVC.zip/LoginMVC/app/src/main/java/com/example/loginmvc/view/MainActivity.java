package com.example.loginmvc.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.loginmvc.R;
import com.example.loginmvc.controller.UsuarioController;
import com.example.loginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {
    ContentValues values;
    UsuarioController controller;
    Usuario usuario;
    EditText userName, password;
    Button signIn, signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean camposValidados = validaCampos();
                if(validaCampos()) {
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                }else{
                    mensagem();
                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                usuario = new Usuario();
                controller = new UsuarioController(getApplicationContext());

                String user   = userName.getText().toString();
                String pass   = password.getText().toString();

                usuario.setEmail(user);
                usuario.setNome(pass);

                if(user.equals("") || pass.equals("")){
                   mensagem();
                }else{
                    controller = new UsuarioController(getApplication());
                    boolean isCheckUser = controller.usuario(user);

                    if(!isCheckUser){
                        Toast.makeText(MainActivity.this, "Usuario Ainda Nao Cadastrado", Toast.LENGTH_SHORT).show();

                    }
                }
                Intent home = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(home);  ;
            }

        });
    }

    private void mensagem() {
        Toast.makeText(MainActivity.this, "Voce tem que preencher todos os campos;", Toast.LENGTH_SHORT).show();
    }

    private boolean validaCampos() {
        boolean camposValidados = true;
        if (userName.getText().toString().equals("") ){
            camposValidados = false;
            userName.setError("Digite o email");
            userName.requestFocus();
        }
        if (password.getText().toString().equals("") ){
            camposValidados = false;
            password.setError("Digite a senha");
            password.requestFocus();
        }
        return camposValidados;
    }


    private void initComponents() {
        userName = findViewById(R.id.user_name);
        password = findViewById(R.id.password);
        signIn = findViewById(R.id.btn_sign_in);
        signUp = findViewById(R.id.btn_sign_up);
    }
}