package com.example.loginmvc.view;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.loginmvc.R;
import com.example.loginmvc.controller.UsuarioController;
import com.example.loginmvc.model.Usuario;

public class MainActivity extends AppCompatActivity {
    UsuarioController controller;
    Usuario usuario;
    EditText userName, password;
    Button signIn, signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initComponents();
        usuario = new Usuario();
        controller = new UsuarioController(getApplicationContext());
        String user   = userName.getText().toString();
        String pass   = password.getText().toString();

        usuario.setEmail(user);
        usuario.setNome(pass);



        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean camposValidados = validaCampos();
                if(camposValidados) {
                    if(!controller.usuario(user)) {
                        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(intent);
                    }else{
                        mensagem("Usuario já cadastrado!");
                        }
                }else{
                    mensagem("Voce tem que preencher todos os campos!");
                }
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                boolean camposValidados = validaCampos();
                if(camposValidados) {
                    controller = new UsuarioController(getApplication());
                    boolean isCheckUser = controller.usuario(user);

                    if(!isCheckUser){
                        mensagem("Usuario Ainda Nao Cadastrado");
                        limpaCampos();
                    }else{
                        boolean isCheckUserPass = controller.usuarioeSenha(user, pass);
                        if(isCheckUserPass) {
                            Intent home = new Intent(MainActivity.this, HomeActivity.class);
                            startActivity(home);
                        }else{
                            mensagem("Usuario ou Senha Inválidos");
                        }
                    }
                }
            }
        });
    }

    private void limpaCampos() {
        userName.setText("");
        password.setText("");
    }

    private void mensagem(String mensagem) {
        Toast.makeText(MainActivity.this, mensagem, Toast.LENGTH_SHORT).show();
    }

    private boolean validaCampos() {
        boolean camposValidados = true;
        if (userName.getText().toString().equals("") ){
            camposValidados = false;
            userName.setError("Digite o email");
            userName.requestFocus();
        }
        if (password.getText().toString().equals("") ){
            camposValidados = false;
            password.setError("Digite a senha");
            password.requestFocus();
        }
        return camposValidados;
    }


    private void initComponents() {
        userName = findViewById(R.id.user_name);
        password = findViewById(R.id.password);
        signIn = findViewById(R.id.btn_sign_in);
        signUp = findViewById(R.id.btn_sign_up);
    }
}